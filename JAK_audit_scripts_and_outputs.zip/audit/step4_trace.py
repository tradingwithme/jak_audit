# Audit step 4: regenerate every manuscript / progress-report number that the archived exports can support.
# Inputs (all in the repo): received_from_student/zip_extracted/merged_category_final_ranked.csv,
#   merged_category_fast_docked.csv, merged_category_topk.csv, merged_category_redocked.csv,
#   merged_project_wandb_compilation.csv.
# Run from the repo root:  python3 -I audit/step4_trace.py > audit/step4_trace_out.txt
# Rule applied: a failed docking (docking_fidelity_refined == cli_fallback_error, score -7.000) is excluded before any
# docking statistic is computed, and the exclusion count is printed. No SMILES are printed.
import itertools, numpy as np, pandas as pd
from rdkit import Chem, DataStructs
from rdkit.Chem import AllChem, Descriptors, rdFingerprintGenerator
from rdkit.Chem.Scaffolds import MurckoScaffold
Z = 'received_from_student/zip_extracted/'
f = pd.read_csv(Z + 'merged_category_final_ranked.csv'); w = pd.read_csv(Z + 'merged_project_wandb_compilation.csv')
fast = pd.read_csv(Z + 'merged_category_fast_docked.csv'); topk = pd.read_csv(Z + 'merged_category_topk.csv'); red = pd.read_csv(Z + 'merged_category_redocked.csv')
fam = {'3EYG':'JAK1','3EYH':'JAK1','2B7A':'JAK2','2W1I':'JAK2','2XA4':'JAK2','3E64':'JAK2','3FUP':'JAK2','3IO7':'JAK2','3IOK':'JAK2','3JY9':'JAK2','3KCK':'JAK2','3KRR':'JAK2','3LPB':'JAK2','1YVJ':'JAK3','3LXK':'JAK3','3PJC':'JAK3','5TTS':'JAK3','6DB3':'JAK3','7C3N':'JAK3'}
f['family'] = f.target_pdb_id.map(fam)
bad = f.docking_fidelity_refined == 'cli_fallback_error'
print(f'[exclusion] failed dockings excluded from docking statistics: {bad.sum()} of {len(f)}; valid kept: {(~bad).sum()}')
v = f[~bad].copy()
v['LE'] = -v.docking_score_refined / v.HeavyAtoms
print('\n== T1 funnel (75 W&B visit records) ==')
fc = [c for c in w.columns if c.startswith('funnel_counts_')]
print(w[fc].sum().to_string())
print('visits by family:', w.protein.value_counts().to_dict(), '| candidates (final_ranked per visit x visits):', w.groupby('protein').funnel_counts_final_ranked.sum().to_dict())
print('visits per cycle label:', w.cycle.value_counts().sort_index().to_dict())
print('exported tables rows: fast', len(fast), 'topk', len(topk), 'redocked', len(red), 'final_ranked', len(f), '| PDBs', f.target_pdb_id.nunique())

print('\n== T2 headline scores, valid redockings only ==')
for fm, g in v.groupby('family'):
    r = g.loc[g.docking_score_refined.idxmin()]
    print(f'{fm}: n_valid={len(g)} best={r.docking_score_refined:.3f} pdb={r.target_pdb_id} HA={int(r.HeavyAtoms)} MW={r.MW:.1f} LE={r.LE:.3f}')
for p in ['3PJC', '3EYH', '3E64']:
    g = v[v.target_pdb_id == p]; r = g.loc[g.docking_score_refined.idxmin()]
    th = f[f.target_pdb_id == p].reference_affinity_target.iloc[0]
    print(f'{p}: best valid {r.docking_score_refined:.3f} (HA {int(r.HeavyAtoms)}, LE {r.LE:.3f}); reference_affinity_target {th:.3f}; gain {th - r.docking_score_refined:+.2f}')
print('tofacitinib LE if -8.433 / 23 HA:', round(8.433 / 23, 3), '(-8.433 is the 3PJC per-target second-best reference, not a per-drug score)')
print('ratio check: 10.53/32 =', round(10.53/32, 3), '| 10.39/31 =', round(10.39/31, 3), '| 9.20/24 =', round(9.20/24, 3))

print('\n== T3 searches for numbers that appear in the manuscript ==')
for name, df in [('fast', fast), ('topk', topk), ('redocked', red), ('final', f)]:
    cols = [c for c in df.columns if c.startswith('docking_')]
    hit = {c: int(((pd.to_numeric(df[c], errors='coerce') + 9.20).abs() < 0.0051).sum()) for c in cols}
    print(f'{name}: rows with a docking value of -9.20 (+-0.005):', hit)
print('rows with HeavyAtoms==24 and MW within 328.3+-0.1 (final):', int(((f.HeavyAtoms == 24) & ((f.MW - 328.3).abs() < 0.1)).sum()),
      '| fast_docked:', int(((fast.HeavyAtoms == 24) & ((fast.MW - 328.3).abs() < 0.1)).sum()))

print('\n== T4 scaffold concentration ==')
core = Chem.MolFromSmarts('c1ncc2cc[nX3]c2n1')
def scaf(s):
    m = Chem.MolFromSmiles(s); return MurckoScaffold.MurckoScaffoldSmiles(mol=m) if m else None
def conc(g, tag):
    n = len(g); has = sum(Chem.MolFromSmiles(s).HasSubstructMatch(core) for s in g.canonical_SMILES)
    sc = g.canonical_SMILES.map(scaf); top = sc.value_counts()
    print(f'{tag}: n={n} contain pyrrolo[2,3-d]pyrimidine core {has} ({100*has/max(n,1):.1f}%); distinct Murcko {sc.nunique()}; largest single scaffold {top.iloc[0]} ({100*top.iloc[0]/n:.1f}%)')
for fm in ['JAK1', 'JAK2', 'JAK3']:
    conc(v[v.family == fm], f'{fm} valid'); conc(f[f.family == fm], f'{fm} all rows')
conc(v, 'ALL valid'); conc(f, 'ALL rows')
print('claimed: JAK1 3/3 (100.0), JAK2 6/7 (85.7), JAK3 9/10 (90.0), pooled 90.0 -> denominators 3, 7, 10 (20 total) do not match any row count above')

print('\n== T5 set-level Tanimoto distance (Morgan r2, 2048 bits), per PDB top-10 block ==')
gen = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=2048)
dist = []
for p, g in f.groupby('target_pdb_id'):
    fps = [gen.GetFingerprint(Chem.MolFromSmiles(s)) for s in g.canonical_SMILES]
    d = [1 - DataStructs.TanimotoSimilarity(a, b) for a, b in itertools.combinations(fps, 2)]; dist.append(np.mean(d))
print(f'mean pairwise distance per block: min {min(dist):.3f} max {max(dist):.3f} mean {np.mean(dist):.3f}; blocks below 0.70: {sum(x < 0.70 for x in dist)} of {len(dist)}')

print('\n== T6 other constants ==')
from rdkit.Chem.FilterCatalog import FilterCatalog, FilterCatalogParams as P
p = P(); p.AddCatalog(P.FilterCatalogs.PAINS); p.AddCatalog(P.FilterCatalogs.BRENK)
print('PAINS+BRENK catalog entries (this RDKit):', FilterCatalog(p).GetNumEntries())
roster = ['3EYG','3EYH','5TOZ','2B7A','2W1I','2XA4','3E64','3FUP','3IO7','3IOK','3JY9','3KCK','3KRR','3LPB','5TQ8','1YVJ','3LXK','3PJC','5TTS','6DB3','7C3N','6GGH','7F7W']
print(f'manuscript Sec. 2.3 lists {len(roster)} PDB entries; exported tables hold {f.target_pdb_id.nunique()}; listed but absent from the tables:', sorted(set(roster) - set(f.target_pdb_id)))
print('W&B gnn_architecture_resolved:', w.gnn_architecture_resolved.value_counts().to_dict())
print('legacy mean LE (valid rows, mean of per-row):', round(v.LE.mean(), 3), '| mean of per-PDB means:', round(v.groupby('target_pdb_id').LE.mean().mean(), 3))
print('legacy mean refined score (valid):', round(v.docking_score_refined.mean(), 3))

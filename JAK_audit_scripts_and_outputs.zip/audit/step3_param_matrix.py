"""Audit step 3: which value does each notebook carry for each parameter?
Input: the notebooks as stored in this repo (code cells of the .ipynb files, or the pasted text files).
Output: audit/step3_param_matrix.csv  (parameter x source: the distinct values found, with how often each occurs)
Read-only: nothing is executed; values are read from the source text by regular expression, so a value built at run time
(for example a roster read from an environment variable) is reported as the expression that builds it."""
import json, re, os, csv, collections
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def nb(p):
    j = json.load(open(os.path.join(R, p)))
    return "\n".join("".join(c["source"]) for c in j["cells"] if c["cell_type"] == "code")
def txt(p): return open(os.path.join(R, p), errors="replace").read()
A = "received_from_student/attachments/"; P = "produced_during_project/"
SRC = collections.OrderedDict([
 ("original (uploads, 19 Oct)",      nb("received_from_student/uploads/DeNovoJAK_Unified_Pipeline.ipynb")),
 ("8f1a936a text (36 cells)",        txt(A + "8f1a936a-attachment.txt")),
 ("356b1212 text (56 cells)",        txt(A + "356b1212-attachment.txt")),
 ("organized build",                 nb(P + "DeNovoJAK_Unified_Pipeline_organized.ipynb")),
 ("modular_before build",            nb(P + "modular_before.ipynb")),
 ("85971945 text (101 cells)",       txt(A + "85971945-attachment.txt")),
 ("96c37c43 run (14 Nov)",           nb(A + "96c37c43-attachment.txt")),
 ("modular build (current)",         nb(P + "DeNovoJAK_Unified_Pipeline_modular.ipynb")),
 ("thesis build (current)",          nb(P + "DeNovoJAK_Unified_Pipeline_thesis.ipynb")),
 ("9b517a30 run (15 Nov)",           nb(A + "9b517a30-attachment.txt")),
])
KEYS = ["gnn_type", "GNN_MODEL_TYPE", "gnn_hidden_dim", "gnn_num_layers", "gnn_heads", "RANDOM_SEED", "seed", "vina_seed", "random_state",
        "learning_rate", "ent_coef", "clip_range", "n_epochs", "max_steps_per_episode", "n_envs", "batch_size",
        "multiplier_floor", "multiplier_ceiling", "adapt_strength", "min_samples_before_adapting",
        "max_mw", "max_logp", "max_hbd", "max_hba", "max_violations", "min_mw", "max_xlogp3", "max_n_or_o", "max_tpsa", "max_rotatable_bonds",
        "max_heavy_atoms", "min_heavy_atoms", "enabled", "min_mcs_atoms",
        "exhaustiveness_low", "exhaustiveness_normal", "exhaustiveness_high", "n_poses", "timeout_seconds", "max_retries", "max_retries_per_visit", "box_size",
        "min_topk_pairwise_distance", "near_duplicate_tanimoto", "scaffold_redundancy_penalty", "top_k"]
def grab(src, key):
    out = collections.Counter()
    for m in re.finditer(r"""["']?\b%s\b["']?\s*[:=]\s*([^,\n}#]{1,60})""" % re.escape(key), src):
        v = m.group(1).strip().rstrip(")").strip()
        out[v] += 1
    return out
rows = []
for k in KEYS:
    for s, t in SRC.items():
        c = grab(t, k)
        rows.append({"parameter": k, "source": s, "values": "; ".join("%s (x%d)" % (v, n) for v, n in c.most_common(6))})
# reward weights: the dict following "reward_weights"
def reward_weights(src):
    out = []
    for m in re.finditer(r'"reward_weights"\s*:\s*\{(.*?)\}', src, re.S):
        body = m.group(1)
        out.append({a: b for a, b in re.findall(r'"(\w+)"\s*:\s*([0-9.]+)', body)})
    return out
for s, t in SRC.items():
    for i, d in enumerate(reward_weights(t)):
        rows.append({"parameter": "reward_weights[#%d]" % i, "source": s, "values": json.dumps(d, sort_keys=True)})
with open(os.path.join(R, "audit", "step3_param_matrix.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["parameter", "source", "values"]); w.writeheader(); w.writerows(rows)
print(len(rows), "rows written")

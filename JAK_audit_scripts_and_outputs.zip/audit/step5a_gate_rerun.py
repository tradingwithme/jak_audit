# Audit step 5a: re-run the notebook's own gate functions on the 190 exported final rows and diff their internal values
# against (i) the descriptors stored in the table and (ii) a literal recomputation.
# Input files:
#   received_from_student/uploads/DeNovoJAK_Unified_Pipeline.ipynb   (gate source; byte-identical in 356b1212, 85971945, modular)
#   received_from_student/zip_extracted/merged_category_final_ranked.csv
# Run from the repo root:  python3 -I audit/step5a_gate_rerun.py > audit/step5a_gate_rerun_out.txt
# The gate functions are EXTRACTED from the notebook text and exec'd unchanged; nothing is re-implemented.
# No SMILES are printed. A failed docking is not involved (descriptors do not depend on docking); the 87/103 split is shown for information.
import json, re, ast, collections
import numpy as np, pandas as pd
from typing import Any, Dict, List, Optional
from rdkit import Chem
from rdkit.Chem import Descriptors, Lipinski, rdMolDescriptors, Crippen, QED
NB = 'received_from_student/uploads/DeNovoJAK_Unified_Pipeline.ipynb'
nb = json.load(open(NB)); cells = [''.join(c['source']) for c in nb['cells'] if c['cell_type'] == 'code']
src_all = '\n'.join(cells)
# CONFIG literal of the notebook (parsed, not evaluated)
cfg_cell = next(c for c in cells if re.search(r'^CONFIG\s*=\s*\{', c, re.M))
i = cfg_cell.index('CONFIG'); i = cfg_cell.index('{', i); depth = 0; j = i; ins = None
while True:
    ch = cfg_cell[j]
    if ins:
        if ch == '\\': j += 1
        elif ch == ins: ins = None
    elif ch in '"\'': ins = ch
    elif ch == '#': j = cfg_cell.index('\n', j)
    elif ch == '{': depth += 1
    elif ch == '}':
        depth -= 1
        if depth == 0: break
    j += 1
try:
    CONFIG = ast.literal_eval(cfg_cell[i:j + 1])
except Exception:
    # the literal contains names (ADAPTIVE[...], best_params[...]); keep only the filters block, which is plain constants
    k = cfg_cell.index('"filters"', i); k = cfg_cell.index('{', k); d = 0; m = k
    while True:
        if cfg_cell[m] == '{': d += 1
        elif cfg_cell[m] == '}':
            d -= 1
            if d == 0: break
        m += 1
    CONFIG = {'filters': ast.literal_eval(cfg_cell[k:m + 1])}
print('gate thresholds from the notebook CONFIG:')
print('  property_range', CONFIG['filters']['property_range'])
print('  lipinski', CONFIG['filters']['lipinski'], '| heavy atoms', CONFIG['filters'].get('min_heavy_atoms'), CONFIG['filters'].get('max_heavy_atoms'))
print('  use_relaxed_lead_likeness', CONFIG['filters'].get('use_relaxed_lead_likeness'))
ns = dict(CONFIG=CONFIG, Chem=Chem, Descriptors=Descriptors, Lipinski=Lipinski, Dict=Dict, Any=Any, List=List, Optional=Optional, np=np)
for fn in ['check_lipinski', 'check_lead_likeness', 'check_property_range']:
    code = re.search(r'^def %s\(.*?(?=^def |^# ---|\Z)' % fn, src_all, re.S | re.M).group(0)
    exec(code, ns)
f = pd.read_csv('received_from_student/zip_extracted/merged_category_final_ranked.csv')
bad = f.docking_fidelity_refined == 'cli_fallback_error'
print(f'\nrows {len(f)} (failed dockings {bad.sum()}, valid {(~bad).sum()}); design_type: {f.design_type.fillna("native").value_counts().to_dict()}')
rows = []
for k, r in f.iterrows():
    mol = Chem.MolFromSmiles(r.canonical_SMILES)
    pr, lp, ll = ns['check_property_range'](mol), ns['check_lipinski'](mol), ns['check_lead_likeness'](mol)
    rows.append(dict(
        idx=k, pdb=r.target_pdb_id, design=('repaired' if r.design_type == 'repaired' else 'native'), failed_docking=bool(bad[k]),
        pr_pass=pr['passed'], pr_viol=';'.join(pr['violations']),
        gate_tpsa=pr['tpsa'], tab_tpsa=r.TPSA, gate_noo=pr['n_or_o'],
        literal_noo=sum(a.GetAtomicNum() in (7, 8) for a in mol.GetAtoms()),
        lip_hba=lp['hba'], tab_hba=r.HBA, gate_mw=pr['mw'], tab_mw=r.MW, gate_logp=pr['xlogp3_proxy'], tab_logp=r.LogP,
        lip_pass=lp['passed'], ll_pass=ll['passed'], ll_viol=';'.join(ll['violations']),
        stored_pr=r.property_range_passed, stored_lip=r.lipinski_passed, stored_ll=r.lead_likeness_passed, stored_hard=r.hard_filter_passed,
        heavy=r.HeavyAtoms, mol_heavy=mol.GetNumHeavyAtoms()))
g = pd.DataFrame(rows)
g.to_csv('audit/step5a_gate_rerun_rows.csv', index=False)
print('\n== 1. does the table store the same descriptors the gate computes? (max abs diff over 190 rows) ==')
print(f'TPSA {np.abs(g.gate_tpsa - g.tab_tpsa).max():.2e} | MW {np.abs(g.gate_mw - g.tab_mw).max():.2e} | LogP {np.abs(g.gate_logp - g.tab_logp).max():.2e} | HBA {int((g.lip_hba != g.tab_hba).sum())} rows differ | heavy atoms {int((g.heavy != g.mol_heavy).sum())} rows differ')
print('gate N+O equals a literal atom count in all rows:', bool((g.gate_noo == g.literal_noo).all()))
print('\n== 2. what the gate now says about the exported rows ==')
print('property_range gate re-run: pass', int(g.pr_pass.sum()), 'fail', int((~g.pr_pass).sum()), '| native fail', int(((~g.pr_pass) & (g.design == 'native')).sum()), '| repaired fail', int(((~g.pr_pass) & (g.design == 'repaired')).sum()))
viol = collections.Counter(v.split('=')[0].split('<')[0].split('>')[0] for s in g.pr_viol for v in s.split(';') if v)
print('violation types among failing rows:', dict(viol))
print('rows failing TPSA:', int(g.pr_viol.str.contains('TPSA').sum()), '| failing N_or_O:', int(g.pr_viol.str.contains('N_or_O').sum()), '| failing both:', int((g.pr_viol.str.contains('TPSA') & g.pr_viol.str.contains('N_or_O')).sum()))
print('rows failing MW floor:', int(g.pr_viol.str.contains('MW<=').sum()), '| failing XLogP:', int(g.pr_viol.str.contains('XLogP').sum()))
print('Lipinski gate re-run: fail', int((~g.lip_pass).sum()), '| lead-likeness gate (strict as configured) fail', int((~g.ll_pass).sum()), '->', dict(collections.Counter(v.split(' ')[0].split('>')[0] for s in g.ll_viol for v in s.split(';') if v)))
print('\n== 3. stored flags versus re-run (native rows carry flags; repaired rows have NaN) ==')
print(pd.crosstab([g.design, g.stored_pr.fillna('NaN').astype(str)], g.pr_pass.map({True: 'rerun pass', False: 'rerun FAIL'})).to_string())
print('hard_filter_passed stored True in', int((g.stored_hard == True).sum()), 'rows; the hard gate (passes_hard_filters) tests only heavy-atom range and structural alerts. It does not include property_range, Lipinski or lead-likeness.')
print('\n== 4. the first hypothesis: Lipinski.NumHAcceptors versus a literal N+O count ==')
print('HBA (Lipinski.NumHAcceptors) vs N+O: HBA<N+O in', int((g.tab_hba < g.literal_noo).sum()), 'rows, equal in', int((g.tab_hba == g.literal_noo).sum()), ', HBA>N+O in', int((g.tab_hba > g.literal_noo).sum()))
print('N+O range', int(g.literal_noo.min()), '-', int(g.literal_noo.max()), '| HBA range', int(g.tab_hba.min()), '-', int(g.tab_hba.max()))
print('rows with N+O >= 9 (gate fails):', int((g.literal_noo >= 9).sum()), '| rows with HBA > 9:', int((g.tab_hba > 9).sum()), '| rows with N+O>=9 but HBA<9:', int(((g.literal_noo >= 9) & (g.tab_hba < 9)).sum()))
print('\n== 5. failing rows by structure and design type ==')
fl = g[~g.pr_pass]
print(fl.groupby(['design']).size().to_dict()); print(fl.groupby('pdb').size().sort_values(ascending=False).to_dict())
print('failing rows with a failed docking (-7.000 placeholder):', int(fl.failed_docking.sum()), 'of', len(fl))
print('\n== 6. descriptor ranges of failing rows ==')
print(fl[['gate_tpsa', 'literal_noo', 'tab_hba']].describe().loc[['min', 'max']].to_string())

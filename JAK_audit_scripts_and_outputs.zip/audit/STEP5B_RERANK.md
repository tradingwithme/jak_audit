# Step 5b: the ranking with and without the failed dockings (read-only; nothing was repaired)

Script `audit/step5b_rerank.py` (output `step5b_rerank_out.txt`; per-row table with both rankings `step5b_rerank_table.csv`).
Input: `received_from_student/zip_extracted/merged_category_final_ranked.csv`. Formula: `finalize_ranking` / `_minmax_normalize` (cell 46 of the original notebook), weights from its CONFIG
(docking 32, QED 12, novelty 12, diversity 8, Lipinski bonus 8, lead-likeness bonus 8, complexity 10, selectivity 10).
The 87 failed dockings (`cli_fallback_error`, -7.000 placeholder) are excluded before any statistic; the count is printed.

## What the exported ranking is

* `rank` is 1 to 10 **within each structure**, from `composite_score` sorted descending. The table is 19 structures x 10 rows: each structure's file (`final_ranked_<PDB>.csv`) holds ranks 1 to 10 once, which is consistent with a single visit's top-10 and not the whole campaign (inference; the files do not name the visit). (Verified: sorting by composite reproduces the exported rank for 19 of 19 structures.)
* `composite_score` is min-max normalised **within the 10 rows of the visit**, and the failed rows' -7.000 enters that normalisation as an ordinary refined score (docking weight 32 of 100). I reproduced the exported composite from the exported columns to 1.1e-13 on all 166 rows that have one.
* **24 rows (all repaired candidates) have NaN `composite_score`** because `diversity_bonus` is NaN for them. `sort_values` puts NaN last, so repaired candidates occupy ranks 7 to 10 whatever their docking score. This is a ranking artefact, not a quality judgement. (In 3IOK the repaired row at rank 10 has a better refined score, -7.401, than the rank-1 row.)
* The refined-docking field is a placeholder for a failure, not a score: the table never marks it with NaN. The docking code also returns -7.0 when the Vina output cannot be parsed, labelled `vina_cli_e<exh>` (not `cli_fallback_error`). I found no such row in the export (0 valid rows with a score of exactly -7.000), so the 87 flagged rows are the whole set here, but that unflagged path exists in the code (cell 22) and would not have been caught by the fidelity label.

## Findings (verified by running the script)

1. **Failures fill almost half of the exported top-10s.** 87 of 190 rows (45.8%). 7 of the 57 top-3 positions and 27 of the 95 top-5 positions are failed dockings. No structure's top-1 is a failure (0 of 19).
2. **No structure has a valid top 10.** Valid rows per structure: minimum 2 (3IOK, 3JY9, 3KCK), median 5, maximum 9; 9 of the 19 structures have fewer than 5; none has 10. Any "top-10 per structure" statement in a thesis chapter would be 2 to 9 real candidates.
3. **Side by side.** The per-structure patterns (V valid, F failed, r repaired with NaN composite, in exported rank order) are in the script output, section 2, e.g. 3E64 VVVFFFFFFF, 3IOK VFFFFFFFFr, 3PJC VVVVVVFFFr.
4. **Removing the failures changes the order of the valid rows less than one might fear, but not nothing.** Recomputing the composite on valid rows only (B) moves 16 of 103 valid rows in 7 of 19 structures; the other 12 structures keep exactly the exported order. The top-1 changes in 3 structures (3IOK, 3JY9, 6DB3). With only 2 to 4 valid rows the min-max normalisation is unstable, so B is not a better ranking there, only a different one.
5. **The pipeline's rank-1 is the best docking score in only 10 of 19 structures.** In the others the best valid score sits at exported rank 2 to 4 (3EYH at rank 4), or at rank 10 in 3IOK. Composite and docking score agree only moderately (median Spearman -0.61 per structure, valid rows with n >= 4).
6. **Headline scores without failures (103 valid rows).** Best valid refined score per structure ranges from -7.286 (3KCK) to -10.530 (3PJC); 72 of 103 valid rows beat their per-target reference threshold, and at least one does in 17 of 19 structures. Three structures (3IOK, 3JY9, 3KCK) have only two valid rows, best scores -7.40, -7.38 and -7.29, barely below the placeholder value -7.0; no conclusion should rest on them.
7. **Combining 5a and 5b matters for the headline numbers.** 8 valid rows fail the property-range gate. Four structures' best valid score changes once they are removed: 3EYG -10.26 to -8.68, **3EYH -10.39 to -9.23**, 3LPB -10.07 to -9.05, 3KCK -7.29 to -7.28. The manuscript's JAK1 headline -10.39 (3EYH) is a row with N+O = 9, which fails the strict "N+O < 9" gate (TPSA 124.7 is within limit). The -10.53 JAK3 row passes (TPSA 107.2, N+O 8). If the gate is the intended standard, the JAK1 headline is **not a gate-compliant candidate**; if the intended gate is looser, the gate in the notebook is the wrong reference. That is a decision for the student and professor; I did not choose.

## Labels proposed (not applied)

* **verified**: 87 of 190 failed; per-structure valid counts; the exported rank and composite formula; the placeholder enters the exported composite; 24 NaN-composite repaired rows sit at ranks 7-10.
* **withdrawn** (cannot stand as written): any ranking, mean or "top-10" figure that includes the 87 placeholder rows; the JAK1 -10.39 as a "gate-passing" headline.
* **pending**: whether the run-time gate was looser (Step 5a); the real top-10 per structure, which needs the unexported 560 candidates (750 evaluated, 190 exported).

## Limits

* The recomputed B ranking uses only the exported 10 rows per structure; the visit's other candidates are not archived (C7 in Step 4).
* Spearman and the median use only structures with at least 4 valid rows.

"""Audit step 3 (second pass): compare the CONFIG literal of each RL notebook version, key by key.
Input: the notebooks in this repo. Output: audit/step3_config_flat.csv (dotted key x source) and audit/step3_config_diff.csv (keys whose value differs).
Method: the first `CONFIG = {...}` literal in each source is parsed with `ast`; constants are read as values, anything computed
(a name, a call, a lookup) is kept as the expression text. Later assignments of the form CONFIG[...][...] = <constant> are applied and
marked "(override)". Nothing is executed."""
import ast, json, re, os, csv, collections
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def nb(p): return "\n".join("".join(c["source"]) for c in json.load(open(os.path.join(R, p)))["cells"] if c["cell_type"] == "code")
def txt(p): return open(os.path.join(R, p), errors="replace").read()
A = "received_from_student/attachments/"; P = "produced_during_project/"
SRC = collections.OrderedDict([
 ("original", nb("received_from_student/uploads/DeNovoJAK_Unified_Pipeline.ipynb")), ("8f1a936a", txt(A + "8f1a936a-attachment.txt")),
 ("356b1212", txt(A + "356b1212-attachment.txt")), ("organized", nb(P + "DeNovoJAK_Unified_Pipeline_organized.ipynb")),
 ("modular_before", nb(P + "modular_before.ipynb")), ("85971945", txt(A + "85971945-attachment.txt")), ("96c37c43", nb(A + "96c37c43-attachment.txt")),
 ("modular", nb(P + "DeNovoJAK_Unified_Pipeline_modular.ipynb")), ("thesis", nb(P + "DeNovoJAK_Unified_Pipeline_thesis.ipynb")),
 ("9b517a30", nb(A + "9b517a30-attachment.txt"))])
def val(n):
    if isinstance(n, ast.Constant): return n.value
    if isinstance(n, ast.Dict): return {(val(k) if k is not None else "**"): val(v) for k, v in zip(n.keys, n.values)}
    if isinstance(n, (ast.List, ast.Tuple)): return [val(x) for x in n.elts]
    if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.USub) and isinstance(n.operand, ast.Constant): return -n.operand.value
    return "<" + ast.unparse(n) + ">"
def literal(src):
    i = src.find("CONFIG = {")
    if i < 0: return None
    j = src.index("{", i); depth = 0; instr = None; k = j
    while k < len(src):
        ch = src[k]
        if instr:
            if ch == "\\": k += 2; continue
            if ch == instr: instr = None
        elif ch == "#":
            k = src.index("\n", k) if "\n" in src[k:] else len(src); continue
        elif ch in "\"'": instr = ch
        elif ch == "{": depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return ast.parse(src[j:k + 1], mode="eval").body, src[k + 1:]
        k += 1
    return None
def flat(d, pre=""):
    out = {}
    for k, v in d.items():
        key = pre + str(k)
        if isinstance(v, dict): out.update(flat(v, key + "."))
        else: out[key] = v
    return out
PAT = re.compile(r'^\s*CONFIG((?:\[\s*["\'][\w]+["\']\s*\])+)\s*=\s*([^\n#]+)', re.M)
res = {}
for s, t in SRC.items():
    r = literal(t)
    if r is None: res[s] = None; continue
    node, rest = r
    f = flat(val(node))
    for m in PAT.finditer(t):
        key = ".".join(re.findall(r'["\'](\w+)["\']', m.group(1)))
        try: v = ast.literal_eval(m.group(2).strip())
        except Exception: v = "<" + m.group(2).strip()[:40] + ">"
        f[key] = "%r (override)" % (v,)
    res[s] = f
keys = sorted({k for f in res.values() if f for k in f})
with open(os.path.join(R, "audit", "step3_config_flat.csv"), "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["key"] + list(SRC))
    for k in keys: w.writerow([k] + [("" if res[s] is None or k not in res[s] else str(res[s][k])) for s in SRC])
diff = [[k] + [("" if res[s] is None or k not in res[s] else str(res[s][k])) for s in SRC] for k in keys]
diff = [r for r in diff if len({x for x in r[1:]}) > 1]
with open(os.path.join(R, "audit", "step3_config_diff.csv"), "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["key"] + list(SRC)); w.writerows(diff)
print({s: (len(f) if f else None) for s, f in res.items()}); print(len(keys), "keys;", len(diff), "differ (incl. present-in-some-only)")

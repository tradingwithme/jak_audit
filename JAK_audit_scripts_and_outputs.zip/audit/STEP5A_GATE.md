# Step 5a: the gate re-run against the exported rows (read-only; nothing was repaired)

Script `audit/step5a_gate_rerun.py` (output `step5a_gate_rerun_out.txt`, per-row table `step5a_gate_rerun_rows.csv`).
Inputs: `received_from_student/uploads/DeNovoJAK_Unified_Pipeline.ipynb` and `received_from_student/zip_extracted/merged_category_final_ranked.csv`.
The notebook's own functions `check_property_range`, `check_lipinski` and `check_lead_likeness` are extracted from the notebook text and executed unchanged
(nothing is re-implemented). Their source is byte-identical in the original, `356b1212`, `85971945` and my modular build (hash-compared), so the answer does not
depend on which of those notebooks is meant. Thresholds are read from the notebook's CONFIG: property range min MW 250, max XLogP 3.5, max N+O 9 (strict `<`), max TPSA 129.9 (strict `<`).
Descriptors do not depend on docking, so all 190 rows are gated; the 87 failed dockings are shown separately and no docking statistic is computed here.

## Result (all verified by running the script)

1. **The stored descriptors are not the problem.** TPSA, MW, LogP, HBA and heavy-atom count in the exported table equal what the gate computes now: maximum absolute difference 2.8e-14
   (TPSA), 5.7e-14 (MW), 1.3e-15 (LogP); 0 rows differ in HBA or heavy atoms; the gate's N+O equals a literal atom count in every row.
2. **The notebook's own gate rejects 48 of the 190 exported rows.** 46 of 166 native rows and 2 of 24 repaired rows. 46 fail N+O (N+O 9 to 13 in those rows), 40 fail TPSA
   (TPSA from the 129.9 limit up to 234.2; median among all 48 failing rows 153.8), 38 fail both. None fails the MW floor or XLogP. Lipinski and (relaxed) lead-likeness fail 0.
3. **All 190 rows carry a stored pass.** `property_range_status` is "pass" in 190 rows; `property_range_violations` is the empty list in all 166 native rows; `property_range_passed` is True
   in 166 and empty in the 24 repaired rows (their status strings are hard-coded "pass" in the repair code). So 46 native rows were recorded as passing a gate that the same function now fails with identical inputs.
4. **`hard_filter_passed` = True in all 190 rows, and that tells nothing about this gate.** `passes_hard_filters` tests only the heavy-atom range (8-60) and the structural alerts. It does not include
   property range, Lipinski or lead-likeness. The name invites the reading "passed the hard filters", which is not what it records.
5. **The first hypothesis (`Lipinski.NumHAcceptors` versus a literal N+O count) is rejected as the explanation.** The gate counts N+O literally (the code comment says so), and HBA is never used in
   `check_property_range`. HBA is below N+O in all 190 rows (HBA 3-9, N+O 5-13). If the gate had used HBA in place of N+O, 1 native row would fail that criterion instead of 45-46, so it would explain
   almost all N+O failures. **It would not explain the TPSA failures:** with HBA substituted and TPSA tested, only 128 of 166 native rows pass (38 fail on TPSA). The stored passes therefore need an explanation that covers TPSA as well.
   (My earlier key `pass_if_gate_used_HBA_instead_of_nO` = 165 in `verification2/gate_diff.json` ignored TPSA; the figure 165 is correct only with TPSA left out. Recorded as a misleading label in my earlier work.)
6. **Which rows.** All failing native rows come from six structures: 3JY9 9, 3IOK 9, 3KCK 9, 3EYG 8, 3LPB 7, 3EYH 6 (JAK2 34, JAK1 12). The other 13 structures have none. The six end their last archived
   visit on 11 Sep 2026 (07:16 to 13:32 UTC), but 3KRR also ends on 11 Sep (10:19) and has no failures, and `final_ranked_<PDB>.csv` does not say which visit a file came from, so I cannot attribute the failures to a date or a build.
7. **Failing rows and failed dockings overlap.** Of the 87 failed dockings, 40 fail the gate (46%); of the 103 valid dockings, 8 do (7.8%). All 48 failing rows: 40 are failed dockings, 8 valid. Descriptive only; I do not know why.
8. **My earlier result is reproduced independently.** `verification2/gate_diff.json` reports the same counts (48, 46, 2, 46 N+O, 40 TPSA, 8 valid failing), now regenerated from the notebook's own code by a separate script.

## What this means for the claim "the gate was enforced"

The funnel code does apply the gate before docking (`check_property_range` on every candidate, then keeps only "pass"), and the repair path calls the same function again before accepting a repaired molecule.
For the 2 repaired rows that now fail, the function was called on the repaired molecule immediately before acceptance, with the same descriptors the table stores. Therefore, **the gate that processed these molecules
at run time was not the function-and-thresholds pair in any archived notebook** (inference from the code path, not proven; the run-time CONFIG is not archived and the W&B configs carry no filter thresholds).
Candidate explanations, none tested because none can be tested from this folder: (a) a different gate version or looser thresholds at run time; (b) the stored flags written without the gate being evaluated for these rows;
(c) the gated molecule differing from the exported SMILES. What would settle it: the run-time notebook or a saved CONFIG for the 2026-09-05 to 09-26 campaign, or any per-visit file holding `property_range_violations` before export.

Consequence for the thesis (not applied): the claim "all final candidates satisfy N+O < 10 and TPSA < 130" (manuscript Fig 1 and 5.1) is **contradicted** for 48 of 190 rows, and cannot be stated for the other 142 until the run-time gate is known.
The ranking effect is Step 5b.

## Limits

* Gate functions were run on the exported canonical SMILES; if the funnel evaluated a differently sanitised molecule, TPSA/N+O could differ. The descriptor columns match to 1e-14, which argues against it for TPSA, MW and LogP, but N+O is not stored in the table.
* The two JAK-family counts rely on the table's `target_protein`.

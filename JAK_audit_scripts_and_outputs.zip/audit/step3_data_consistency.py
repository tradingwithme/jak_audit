# Input: received_from_student/zip_extracted/merged_category_final_ranked.csv and merged_project_wandb_compilation.csv
# Purpose (audit step 3): which parameter values are the exported tables consistent with? Read-only; no fixes.
import pandas as pd
z='received_from_student/zip_extracted/'
f=pd.read_csv(z+'merged_category_final_ranked.csv'); w=pd.read_csv(z+'merged_project_wandb_compilation.csv')
print('final_ranked rows',len(f),'| fidelity counts:',f.docking_fidelity_refined.value_counts().to_dict())
print('\n-- all 190 rows (failed dockings are not a docking statistic here; descriptors are independent of docking) --')
for c in ['MW','TPSA','HeavyAtoms','RotBonds','LogP','HBD','HBA']:
    print(f'{c:10s} min {f[c].min():8.2f} max {f[c].max():8.2f}')
print('MW<250:',(f.MW<250).sum(),'| MW<200:',(f.MW<200).sum(),'| MW>450:',(f.MW>450).sum(),'| MW>500:',(f.MW>500).sum())
print('TPSA>129.9:',(f.TPSA>129.9).sum(),'| TPSA>140:',(f.TPSA>140).sum())
print('RotBonds>10:',(f.RotBonds>10).sum(),'| >12:',(f.RotBonds>12).sum())
print('HeavyAtoms<8:',(f.HeavyAtoms<8).sum(),'| >60:',(f.HeavyAtoms>60).sum())
print('LogP>4.5:',(f.LogP>4.5).sum(),'| >5.0:',(f.LogP>5.0).sum())
print('\nstatus columns:')
for c in ['property_range_passed','lead_likeness_passed','lipinski_passed','structural_alerts_passed','essential_scaffold_passed','essential_scaffold_applicable','hard_filter_passed']:
    print(' ',c,f[c].value_counts(dropna=False).to_dict())
print('\n-- docking_fidelity_refined by pdb --'); print(pd.crosstab(f.target_pdb_id,f.docking_fidelity_refined).to_string())
print('\n-- wandb compilation --')
print('rows',len(w),'| gnn_architecture_resolved',w.gnn_architecture_resolved.value_counts(dropna=False).to_dict(),'| backend',w.docking_backend.value_counts(dropna=False).to_dict())
print('cycle range',w.cycle.min(),w.cycle.max(),'| pdb',w.pdb_id.nunique(),'| sum final_ranked',w.funnel_counts_final_ranked.sum(),'| sum n_final_candidates',w.n_final_candidates.sum())
print('passed_essential_scaffold == passed_structural_alerts in',(w.funnel_counts_passed_essential_scaffold==w.funnel_counts_passed_structural_alerts).sum(),'of',len(w),'visits')
print('generated_at_utc range',w.generated_at_utc.min(),w.generated_at_utc.max())

# Audit step 5b: re-rank the 190 exported final rows with the failed dockings excluded, side by side with the exported ranking.
# Input: received_from_student/zip_extracted/merged_category_final_ranked.csv
# Formula source: finalize_ranking and _minmax_normalize in received_from_student/uploads/DeNovoJAK_Unified_Pipeline.ipynb (cell 46);
#   weights from its CONFIG["ranking"]["weights"]: docking 32, qed 12, novelty 12, diversity 8, lipinski bonus 8, lead-likeness bonus 8, complexity 10, selectivity 10.
# Run from the repo root:  python3 -I audit/step5b_rerank.py > audit/step5b_rerank_out.txt
# Failed dockings (docking_fidelity_refined == cli_fallback_error, score -7.000 placeholder) are excluded BEFORE any recomputation; the count is printed.
# No SMILES are printed. Outputs: audit/step5b_rerank_table.csv (one row per exported row, both rankings).
import numpy as np, pandas as pd
W = dict(docking=32.0, qed=12.0, novelty=12.0, diversity=8.0, lip=8.0, lead=8.0, complexity=10.0, selectivity=10.0)
f = pd.read_csv('received_from_student/zip_extracted/merged_category_final_ranked.csv')
f['failed'] = f.docking_fidelity_refined == 'cli_fallback_error'
print(f'rows {len(f)} over {f.target_pdb_id.nunique()} structures (10 each); failed dockings to exclude: {f.failed.sum()}; valid: {(~f.failed).sum()}')

def mm(s):
    s = s.astype(float); lo, hi = s.min(), s.max()
    if not np.isfinite(lo) or not np.isfinite(hi) or hi - lo < 1e-9: return pd.Series(0.5, index=s.index)
    return (s - lo) / (hi - lo)

def composite(d):
    dock = mm(-d.docking_score_refined.fillna(d.docking_score_refined.median()))
    return (W['docking'] * dock + W['qed'] * mm(d.QED) + W['novelty'] * mm(d.novelty_score) + W['diversity'] * mm(d.diversity_bonus)
            + W['lip'] * (d.Lipinski_status == 'pass').astype(float) + W['lead'] * (d.lead_likeness_status == 'pass').astype(float)
            + W['complexity'] * mm(d.complexity_desirability) + W['selectivity'] * mm(1.0 - d.p_share_target))

# 1. can the exported composite be reproduced from the exported columns (all 10 rows of each structure, placeholders included)?
f['comp_repro'] = np.nan
for p, g in f.groupby('target_pdb_id'): f.loc[g.index, 'comp_repro'] = composite(g)
ok = f.composite_score.notna()
print('\n== 1. reproduction of the exported composite_score from the exported columns ==')
print(f'rows with an exported composite: {ok.sum()}; max |reproduced - exported| = {(f.comp_repro - f.composite_score)[ok].abs().max():.3e}')
print(f'rows with NaN exported composite: {(~ok).sum()} (all repaired rows with NaN diversity_bonus: {int((f.diversity_bonus.isna() & ~ok).sum())}); NaN reproduced: {int(f.comp_repro.isna().sum())}')
# the exported rank: sort by composite descending, NaN last
print('exported rank is 1..10 within each structure; check = sort by composite (NaN last):', end=' ')
chk = 0
for p, g in f.groupby('target_pdb_id'):
    o = g.sort_values('composite_score', ascending=False, kind='stable'); chk += int((o['rank'].values == np.arange(1, 11)).all())
print(f'{chk} of 19 structures consistent')

# 2. rankings side by side
ex = f.copy(); ex['rank_exported'] = ex['rank']
v = f[~f.failed].copy()
v['rank_A_keep_order'] = v.groupby('target_pdb_id')['rank'].rank(method='first').astype(int)       # A: same ordering, failed rows removed
v['comp_B'] = np.nan
for p, g in v.groupby('target_pdb_id'): v.loc[g.index, 'comp_B'] = composite(g)                        # B: composite recomputed on the valid rows only
v['rank_B_recomputed'] = v.groupby('target_pdb_id').comp_B.rank(ascending=False, method='first', na_option='bottom').astype(int)
v['rank_C_score_only'] = v.groupby('target_pdb_id').docking_score_refined.rank(method='first').astype(int)  # C: refined docking score alone (more negative = better)
out = f[['target_pdb_id', 'target_protein', 'rank', 'failed', 'composite_score', 'docking_score_refined', 'design_type']].rename(columns={'rank': 'rank_exported'}).join(
    v[['rank_A_keep_order', 'comp_B', 'rank_B_recomputed', 'rank_C_score_only']])
out.to_csv('audit/step5b_rerank_table.csv', index=False)

print('\n== 2. per-structure side by side. Exported top-10 reads left to right (F = failed docking placeholder, r = repaired row with NaN composite); B = recomputed over valid rows ==')
print(f'{"PDB":5s} {"valid":>5s}  exported ranks 1..10 (V valid, F failed)    top-1 exported -> top-1 B (valid)   best valid by score (rank_exported)')
tops = []
for p, g in f.groupby('target_pdb_id'):
    s = g.sort_values('rank'); pattern = ''.join(('F' if r.failed else ('r' if r.design_type == 'repaired' else 'V')) for _, r in s.iterrows())
    gv = v[v.target_pdb_id == p]
    b1 = gv.sort_values('rank_B_recomputed').iloc[0]; a1 = gv.sort_values('rank_A_keep_order').iloc[0]; c1 = gv.sort_values('rank_C_score_only').iloc[0]
    e1 = s.iloc[0]
    tops.append(dict(pdb=p, valid=len(gv), exp_top_failed=bool(e1.failed), A_top=int(a1['rank']), B_top=int(b1['rank']), C_top=int(c1['rank']),
                     B_score=b1.docking_score_refined, C_score=c1.docking_score_refined))
    print(f'{p:5s} {len(gv):5d}  {pattern}    exported#1 {"FAILED" if e1.failed else "valid "} | B#1 = exported rank {int(b1["rank"]):2d}  | C#1 = exported rank {int(c1["rank"]):2d}')
T = pd.DataFrame(tops)
print('\n== 3. summary ==')
print(f'structures where the exported rank-1 row is a failed docking: {int(T.exp_top_failed.sum())} of 19')
print(f'valid rows per structure: min {T.valid.min()} max {T.valid.max()} median {T.valid.median():.0f}; structures with fewer than 5 valid: {int((T.valid < 5).sum())}; with fewer than 10: {int((T.valid < 10).sum())} (all 19)')
print(f'exported top-10 positions occupied by failed dockings: {int(f.failed.sum())} of 190 ({100*f.failed.mean():.1f}%); in the exported top 3 of each structure: {int(((f["rank"] <= 3) & f.failed).sum())} of 57; in the top 5: {int(((f["rank"] <= 5) & f.failed).sum())} of 95')
print('exported rank-1 row is the best valid score of its structure (C#1 equals exported rank 1):', int((T.C_top == 1).sum()), 'of 19 | B#1 (recomputed composite) differs from A#1 (same order, failed removed):', int((T.A_top != T.B_top).sum()), 'of 19')
rk = []
for p, g in v.groupby('target_pdb_id'):
    if len(g) >= 4: rk.append(g.composite_score.corr(g.docking_score_refined, method='spearman') if g.composite_score.notna().sum() >= 4 else np.nan)
print(f'Spearman (exported composite vs refined score) per structure, valid rows only (n>=4): median {np.nanmedian(rk):.2f} (sign: negative = better composite goes with lower, i.e. better, score)')
# position of the top-3 de novo (native) rows under A versus exported rank
print('mean exported rank of valid rows:', round(v['rank'].mean(), 2), '| of failed rows:', round(f[f.failed]['rank'].mean(), 2), '| repaired rows (NaN composite): all at the tail:', sorted(f[f.design_type == 'repaired']['rank'].unique().tolist()))
print('\n== 4. headline statistics WITHOUT failures (103 valid rows) ==')
vb = v.loc[v.groupby('target_pdb_id').docking_score_refined.idxmin()]
print('best valid refined score per structure:'); print(vb[['target_pdb_id', 'docking_score_refined', 'rank']].rename(columns={'rank': 'exported_rank'}).to_string(index=False))
print('beats the per-target reference threshold: valid rows', int(v.beats_reference_affinity_target.sum()), 'of', len(v), '| structures with at least one:', int(v.groupby('target_pdb_id').beats_reference_affinity_target.any().sum()), 'of 19')

print('\n== 5. how much does leaving the placeholders out change the order of the valid rows? ==')
chg = v[v.rank_A_keep_order != v.rank_B_recomputed]
print(f'valid rows whose position differs between A (same order, failed removed) and B (composite recomputed on valid rows): {len(chg)} of {len(v)}; structures with any change: {chg.target_pdb_id.nunique()} of 19')
print('structures where the whole order is unchanged:', 19 - chg.target_pdb_id.nunique(), '| note: B places NaN-composite repaired rows last by construction, as the exported ranking does')
print('\n== 6. combining 5a and 5b: valid dockings that ALSO pass the property-range gate re-run (audit/step5a_gate_rerun_rows.csv) ==')
g = pd.read_csv('audit/step5a_gate_rerun_rows.csv').set_index('idx')
v2 = v.join(g[['pr_pass']]); vp = v2[v2.pr_pass]
print(f'valid rows {len(v2)}; valid and gate pass {len(vp)}; structures with no valid gate-passing row: {sorted(set(v2.target_pdb_id) - set(vp.target_pdb_id))}')
bb = vp.loc[vp.groupby('target_pdb_id').docking_score_refined.idxmin()].set_index('target_pdb_id').docking_score_refined
ba = vb.set_index('target_pdb_id').docking_score_refined
d = (bb - ba.reindex(bb.index)).round(3); print('structures whose best valid score changes once gate failures are removed:', {k: (float(ba[k]), float(bb[k])) for k in d[d != 0].index})

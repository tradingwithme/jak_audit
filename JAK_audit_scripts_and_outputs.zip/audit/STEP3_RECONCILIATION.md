# Step 3: reconciliation of the notebooks (read-only; nothing was changed or fixed)

Method. `audit/step3_config_diff.py` parses the `CONFIG = {...}` literal of each notebook source with `ast` and compares
key by key (output: `step3_config_flat.csv`, 200 keys). Later `CONFIG[...] = const` assignments are marked "(override)";
names and calls are kept as expression text, not evaluated. `audit/step3_param_matrix.py` is a looser regex pass
(`step3_param_matrix.csv`, noisy; used only to find candidates). `audit/step3_data_consistency.py` reads the exported tables
(`step3_data_consistency_out.txt`). The W&B values come from `attachments/1d84f794-wandb_audit_runs.csv` (two runs).

Sources compared (10): `original` (the uploaded RL notebook), `8f1a936a` (pasted; has **no** CONFIG cell, so it is absent from every
comparison below), `organized` (my intermediate build of `original`), `356b1212`, `modular_before`, `85971945`, `96c37c43` (Colab run,
14 Nov), `modular`, `thesis` (my current builds), `9b517a30` (student-edited modular, Colab run, 15 Nov).

Labels: **verified** = read directly from the named file; **pending** = needs Step 4/5; **cannot tell** = the exported data does not
distinguish the values.

## 1. Result in one line

Of 200 CONFIG keys, 10 have different values across the sources, and 60 exist in only some of them (the later builds added them).
The RL line has **no MMR** anywhere (verified: no match for MMR, "maximal marginal" or a lambda parameter in any RL notebook,
code or output). The manuscript describes MMR with lambda = 0.60; that description matches the edit-family notebook, not the RL line.

## 2. Parameters whose value differs between RL notebooks (verified from the files)

| Parameter | Values by source | Which does the exported data support? |
|---|---|---|
| `rl.ent_coef` | 0.01 in `original`, `organized`; 0.05 in all others (`356b1212` onward) and in W&B run B | **cannot tell** from the tables. The tables contain no policy hyperparameters. Run B records 0.05. |
| `rl.max_steps_per_episode` | 8 in `original`, `organized`; 12 in all others and in W&B run B | **cannot tell** (same reason). |
| `docking.timeout_seconds` | 60 in `original`, `organized`; `ADAPTIVE['timeout_seconds']` in all others; W&B run B 240 | The 75-visit tables record 0 timeouts only through `oracle_stats_n_failed`; they carry no timeout setting. **cannot tell**. Run B (cycle 477) records 240 s and 28 timeouts in `oracle_stats` (8 under failure reason "timeout"). |
| `docking.exhaustiveness_high` | 8 in `original`, `organized`; `ADAPTIVE[...]` in `356b1212`, `modular_before`, `modular`, `9b517a30`; hard-coded 8 (override) in `85971945`, `96c37c43`, `thesis`; W&B run B **4** | The tables label the fast stage `vina_cli_e1` (190 of 190) and the refined stage `vina_cli_e8` (103 of 103 successes). That fits `exhaustiveness_low` = 1 and a redocking exhaustiveness of 8 (run B `redocking.exhaustiveness` = 8). It says nothing about `exhaustiveness_high`, which is not a label in the tables. **cannot tell**. |
| `filters.essential_scaffold.enabled` | False (override) in `original`; False in `organized`; True in `356b1212`, `modular_before`, `85971945`, `96c37c43`, `modular`, `thesis`; False in `9b517a30` | In all 75 visits `funnel_counts_passed_essential_scaffold` equals `funnel_counts_passed_structural_alerts`, so the scaffold filter removed nothing in the legacy data. That is consistent with `original` (disabled). It does not by itself show the filter was disabled (it could have passed everything). **consistent with False; not proof.** |
| `generation.n_inference_molecules` | `ADAPTIVE[...]` in `original`, `356b1212`, `organized`, `modular_before`, `modular`, `9b517a30`; 100 (override) in `85971945`, `96c37c43`, `thesis` | `funnel_counts_generated` in the compilation is the observable. Step 4 compares it to 100 and to the adaptive value. **pending** |
| `novelty.near_duplicate_tanimoto` | from `best_params[...]` in `original`, `organized`; from `NOVELTY_CHOICE.threshold` in the rest | Not a literal. Depends on a tuning cell's output. **pending** (needs the saved `best_params`, not in the folder). |
| `novelty.scaffold_redundancy_penalty` | `best_params["scaffold_penalty"]` in `original`, `organized`; 0.3 in the rest | Same. **pending** |
| `seeds.counterparts_per_seed` | 50 in `original`, `organized`; a variable in the rest; W&B run B 8 (after the min-counterpart clamp: `min_counterparts_per_seed` 8, `_meta.adaptive_snapshot.counterparts_per_seed` 10) | **cannot tell** |
| `seeds.min_counterparts_per_seed` | 10 in `original`, `organized`; `min(10, COUNTERPARTS_PER_SEED)` in the rest | Follows from the line above. |

The `original` and `organized` pair always agree with each other; `356b1212` and everything after it agree with each other except for
the four hard-coded overrides above. The change between the two groups is a single step: `original` to `356b1212`.
Which group produced the 75 exported visits is **pending** (Step 4): the compilation's `generated_at_utc` runs 2026-09-05 to 2026-09-26,
while the outputs saved in `original` contain no dates (verified: no date string in any output), and W&B run A is dated 30 Aug 2026
(cycle 12, GraphSAGE) and run B 4 Sep 2026 (cycle 477). Run B's cycle 477 is later than the compilation's last cycle (474) yet its date
(4 Sep) is earlier than the compilation's first `generated_at_utc` (5 Sep). I cannot reconcile those two facts from the files.

## 3. Parameters identical in every RL source that has a CONFIG (verified)

Reward weights (docking 15, lipinski 20, property_range 20, lead_likeness 15, novelty 15, diversity 10, qed 10, complexity 12,
structural_alerts 20, essential_scaffold 25, selectivity 15, beats_reference_affinity 20, validity 1, seed_relatedness 10);
`campaign_scaffold_repeat` 15 exists only from `356b1212` onward. Filters: `property_range` min_mw 250, max_tpsa 129.9, max_n_or_o 9,
max_xlogp3 3.5; lead-likeness 250-450 Da, logP <= 4.5, rotatable bonds <= 10 (relaxed: 200-500, 5.0, 12); Lipinski MW 500, logP 5,
HBD 5, HBA 10, 0 violations; heavy atoms 8-60. GNN: 3 layers, 128 hidden, 4 heads. Box 20.0, `exhaustiveness_low` 1, `_normal` 4.
The reward weights are therefore **not** a source of drift between notebooks. Whether they were the weights of the exported run is
**pending** (Step 4); only run B's values (`generation.reward_weights.seed_relatedness` 10) are recorded elsewhere.

## 4. GNN architecture (verified from the files)

* `GNN_MODEL_TYPE` default: `GCN` in `original`, `organized`, `356b1212`, `modular_before`, `85971945`, `96c37c43`; `GraphSAGE` in `modular`,
  `thesis` (my current builds) and `9b517a30` (the student's executed copy).
* The compilation's `gnn_architecture_resolved` is GraphSAGE for 58 of the 75 visits and GCN for 17. The 75 visits are therefore **not** from one
  architecture. A single manuscript statement "GCN-PPO" is contradicted by 58 of them.
* W&B run A: `gnn_type` GraphSAGE (cycle 12). Run B: `model.gnn_type` GCN, `gnn_architecture_resolved` GCN, `gnn_backend_available` False (cycle 477, 4 Sep).
  The 9b517a30 run printed "Resolved architecture : GraphSAGE" (verified). Run B (GCN, cycle 477) and the 9b517a30 visits (cycles 475-477) overlap in cycle numbers
  but record different architectures, so they cannot be the same visits.
* `model.gnn_heads` = 4 appears in every CONFIG, but in the `DenseMPLayer` code the `heads` argument is used only in GAT and GATv2 mode. In GCN and
  GraphSAGE mode it has no effect. The manuscript's "GCN; 3 layers, 128 hidden, 4 attention heads" therefore describes a setting that did not act on a GCN. (verified from `original` cell 20)

## 5. The edit-family notebook versus the RL line

`80a98e20-attachment.txt` is text only; the .ipynb is not in the folder. Its configuration (lines 56-111) differs from the RL line:

| Setting | Edit family (`80a98e20`) | RL line |
|---|---|---|
| MMR lambda | 0.6 (`mmr_lambda`, line 111; `mmr_select` at line 1385) | no MMR |
| `mw_min` | 150.0 (line 56) | 250 (200 relaxed) |
| `tpsa_max` | 140.0 (line 61) | 129.9 |
| `rotb_max` | 10 (line 62); an inline `RepairConfig` uses 6 | 10 (12 relaxed) |
| `hba_max` | 10 (line 60); `RepairConfig` 8 | 10 (Lipinski) |
| selection | chunked Pareto then MMR; seven edit families; random-forest surrogate; calibrator | PPO over a fragment-growth policy; no Pareto, no surrogate |

The manuscript text on MMR (paragraphs 21, 62-63: "lambda = 0.60"), "seven independent edit families" (paragraph 83) and the Pareto and
surrogate sentences describe the edit family. The GNN, PPO and reward sections (paragraphs 7, 17, 34) describe the RL line. The manuscript
mixes the two code lines. Which statements belong to which is a Step 4 task.

## 6. What the exported tables are consistent with (verified; `step3_data_consistency_out.txt`)

| Quantity | In `final_ranked` (190 rows) | Reading |
|---|---|---|
| MW | 250.26 to 491.52; none below 250; 9 above 450; none above 500 | consistent with the RL floor 250; **not** with 150. The 9 above 450 exceed the lead-likeness cap but fit the relaxed 500 cap. |
| TPSA | 56.84 to 234.24; **40 rows above 129.9**, 33 above 140 | **contradicts** `max_tpsa` 129.9 and the edit-family 140. All 190 rows carry `hard_filter_passed` = True. Step 5a. |
| HBA | 3 to 9 | consistent with <= 10 |
| rotatable bonds | 1 to 6 | consistent with <= 10 and <= 12 |
| heavy atoms | 17 to 37 | consistent with 8 to 60 |
| logP | -2.85 to 3.48 | consistent with <= 4.5 |
| status columns | `property_range_passed` etc. True in 166 rows, empty in 24 | 24 rows carry no filter status; Step 4/5a |
| docking | fast stage `vina_cli_e1` in 190 of 190; refined `vina_cli_e8` 103, `cli_fallback_error` 87 (the 87 carry `docking_score_refined` = -7.000 and an empty raw score) | failures are placeholders, as CLAUDE.md states. `pose_energy_std` is 0.0 in all 190 rows. |
| visits | 75 rows over 19 PDB structures, cycles 1 to 474; backend `FastVinaOracle` in all 75 | `funnel_counts_final_ranked` sums to **750**, `n_final_candidates` to 750; the exported `final_ranked` table has **190** rows. Step 4. |

## 7. Findings that are about my own code (recorded, not repaired)

* The roster preview in the modular and thesis builds flags a structure as having "few protein neighbours" at a threshold of 150. The threshold was
  never calibrated, and in the 9b517a30 run it flagged all eight real inhibitor ligands.
* A previously saved policy is adopted by vocabulary size against the post-acquisition library. When acquisition adds fragments, a 241-fragment
  policy no longer matches a 256-fragment library, so the learned head is dropped (9b517a30 run: kept 0, added 256, dropped 241). This invalidates any
  comparison that assumes the 9b517a30 visits continued the earlier policy.

## 8. Not resolved by Step 3

* Which notebook version produced the 75 legacy visits and the 190 exported rows (the tables carry no config hash). Needs Step 4.
* The `best_params` file behind `novelty.*`; no such file is in the folder.
* The seed values: `rl.seed` and `docking.vina_seed` are 42 in run B only; the notebooks define `RANDOM_SEED` by name. I did not find a seed file.
* Whether the 87 failures (46 percent of the 190) arise from the `embedding_failed` path (18 in the 9b517a30 run) or another one. Step 5b needs this.
